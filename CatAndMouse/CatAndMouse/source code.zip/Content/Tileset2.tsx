<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset2" tilewidth="96" tileheight="96" tilecount="1" columns="1">
 <image source="Tile2.png" width="96" height="96"/>
</tileset>
