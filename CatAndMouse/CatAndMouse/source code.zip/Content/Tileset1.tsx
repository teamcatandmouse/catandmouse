<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset1" tilewidth="96" tileheight="96" tilecount="1" columns="1">
 <image source="Tile1.png" width="96" height="96"/>
</tileset>
